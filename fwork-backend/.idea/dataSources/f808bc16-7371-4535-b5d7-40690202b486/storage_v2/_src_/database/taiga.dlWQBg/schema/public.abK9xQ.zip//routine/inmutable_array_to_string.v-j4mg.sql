create function inmutable_array_to_string(text[]) returns text
    immutable
    language sql
as
$$
SELECT array_to_string($1, ' ', '')
$$;

alter function inmutable_array_to_string(text[]) owner to taiga;

