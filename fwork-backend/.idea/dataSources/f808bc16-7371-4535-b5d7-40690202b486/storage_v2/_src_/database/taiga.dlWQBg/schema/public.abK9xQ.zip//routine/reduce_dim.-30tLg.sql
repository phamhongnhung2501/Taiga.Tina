create function reduce_dim(anyarray) returns SETOF anyarray
    immutable
    language plpgsql
as
$$
DECLARE
                s $1%TYPE;
            BEGIN
                IF $1 = '{}' THEN
                	RETURN;
                END IF;
                FOREACH s SLICE 1 IN ARRAY $1 LOOP
                    RETURN NEXT s;
                END LOOP;
                RETURN;
            END;
$$;

alter function reduce_dim(anyarray) owner to taiga;

