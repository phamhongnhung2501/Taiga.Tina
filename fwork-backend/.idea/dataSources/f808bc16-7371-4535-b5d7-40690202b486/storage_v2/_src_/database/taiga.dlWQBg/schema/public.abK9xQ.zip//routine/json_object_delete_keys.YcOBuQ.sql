create function json_object_delete_keys(json json, VARIADIC keys_to_delete text[]) returns json
    immutable
    strict
    language sql
as
$$
SELECT COALESCE ((SELECT ('{' || string_agg(to_json("key") || ':' || "value", ',') || '}')
                                       FROM json_each("json")
                                      WHERE "key" <> ALL ("keys_to_delete")),
                                    '{}')::json
$$;

alter function json_object_delete_keys(json, text[]) owner to taiga;

