create function json_object_delete_keys(json jsonb, VARIADIC keys_to_delete text[]) returns jsonb
    immutable
    strict
    language sql
as
$$
SELECT COALESCE ((SELECT ('{' || string_agg(to_json("key") || ':' || "value", ',') || '}')
                                       FROM jsonb_each("json")
                                      WHERE "key" <> ALL ("keys_to_delete")),
                                    '{}')::text::jsonb
$$;

alter function json_object_delete_keys(jsonb, text[]) owner to taiga;

