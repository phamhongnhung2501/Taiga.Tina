create function array_distinct(anyarray) returns anyarray
    language sql
as
$$
SELECT ARRAY(SELECT DISTINCT unnest($1))
$$;

alter function array_distinct(anyarray) owner to taiga;

